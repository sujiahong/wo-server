window._CCSettings = {
    platform: "android",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    rawAssets: {
        assets: {}
    },
    launchScene: "db://assets/Scene/LogoScene.fire",
    scenes: [
        {
            url: "db://assets/Scene/LogoScene.fire",
            uuid: "1b6iG9dNNHmZdIYCnF34lR"
        },
        {
            url: "db://assets/Scene/HotUpdateScene.fire",
            uuid: "f9K0EFFPlHgrb/62iqKCUg"
        },
        {
            url: "db://assets/Scene/LoginScene.fire",
            uuid: "eb24tg7z5Oi6Qq+AuL7CuG"
        },
        {
            url: "db://assets/Scene/HomeScene.fire",
            uuid: "f6WMewfU1KS6QRJfxDO6QJ"
        }
    ],
    packedAssets: {},
    md5AssetsMap: {},
    orientation: "",
    debug: true,
    subpackages: {}
};
