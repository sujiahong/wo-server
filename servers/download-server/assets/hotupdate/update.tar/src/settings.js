window._CCSettings = {
    platform: "android",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    rawAssets: {
        assets: {}
    },
    launchScene: "db://assets/Scene/LogoScene.fire",
    scenes: [
        {
            url: "db://assets/Scene/LogoScene.fire",
            uuid: "1b6iG9dNNHmZdIYCnF34lR"
        },
        {
            url: "db://assets/Scene/HotUpdateScene.fire",
            uuid: "f9K0EFFPlHgrb/62iqKCUg"
        },
        {
            url: "db://assets/Scene/LoginScene.fire",
            uuid: "eb24tg7z5Oi6Qq+AuL7CuG"
        },
        {
            url: "db://assets/Scene/HomeScene.fire",
            uuid: "f6WMewfU1KS6QRJfxDO6QJ"
        }
    ],
    packedAssets: {
        "03b15c223": [
            "a2MjXRFdtLlYQ5ouAFv/+R",
            "f6WMewfU1KS6QRJfxDO6QJ"
        ],
        "059217707": [
            "a2MjXRFdtLlYQ5ouAFv/+R",
            "f9K0EFFPlHgrb/62iqKCUg"
        ],
        "0b38bb553": [
            "02delMVqdBD70a/HSD99FK",
            "71VhFCTINJM6/Ky3oX9nBT",
            "b4P/PCArtIdIH38t6mlw8Y",
            "d8HsitJHxOYqo801xBk8ev",
            "e8Ueib+qJEhL6mXAHdnwbi"
        ],
        "0bc07086d": [
            "29FYIk+N1GYaeWH/q1NxQO",
            "a2MjXRFdtLlYQ5ouAFv/+R",
            "e97GVMl6JHh5Ml5qEDdSGa",
            "eb24tg7z5Oi6Qq+AuL7CuG",
            "f0BIwQ8D5Ml7nTNQbh1YlS"
        ],
        "0bea27fc8": [
            "1b6iG9dNNHmZdIYCnF34lR",
            "9bvaMerUlDyary99mJa6xp"
        ]
    },
    md5AssetsMap: {},
    orientation: "",
    debug: true,
    subpackages: {}
};
